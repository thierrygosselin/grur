/* This file is part of Metasim
   This file is teh declaration of the locus object type.
*/


/* includes */
#include <metasim.h>
#include <Genotype.h>



/*
;;; Local Variables: ***
;;; mode: C++ ***
;;; minor-mode:  font-lock  ***
;;; End:  ***
*/




